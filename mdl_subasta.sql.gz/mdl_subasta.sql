-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 19, 2010 at 09:05 PM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `subasta_cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `mdl_subasta`
--

CREATE TABLE IF NOT EXISTS `mdl_subasta` (
  `sub_uid` int(11) NOT NULL,
  `sub_pca_uid` int(11) NOT NULL,
  `sub_usr_uid` int(11) DEFAULT NULL,
  `sub_description` varchar(255) DEFAULT NULL,
  `sub_type` enum('COMPRA','VENTA') DEFAULT NULL,
  `sub_modalidad` varchar(255) DEFAULT NULL,
  `sub_date` date DEFAULT NULL,
  `sub_hour` time DEFAULT NULL,
  `sub_mount_base` double(20,2) DEFAULT NULL,
  `sub_moneda` varchar(255) DEFAULT NULL,
  `sub_mount_unidad` double(20,2) DEFAULT NULL,
  `sub_hour_end` datetime DEFAULT NULL,
  `sub_tiempo` int(11) DEFAULT '0',
  `sub_status` enum('ACTIVE','INACTIVE') DEFAULT NULL,
  `sub_delete` int(11) DEFAULT NULL,
  `sub_deadtime` datetime NOT NULL,
  `sub_finish` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sub_uid`,`sub_pca_uid`),
  KEY `pca_uid` (`sub_pca_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mdl_subasta`
--

INSERT INTO `mdl_subasta` (`sub_uid`, `sub_pca_uid`, `sub_usr_uid`, `sub_description`, `sub_type`, `sub_modalidad`, `sub_date`, `sub_hour`, `sub_mount_base`, `sub_moneda`, `sub_mount_unidad`, `sub_hour_end`, `sub_tiempo`, `sub_status`, `sub_delete`, `sub_deadtime`, `sub_finish`) VALUES
(1, 1, 1, 'celular con camara', 'COMPRA', 'TIEMPO', '2010-10-16', '15:43:00', 220.00, 'USD', 2.50, '2010-10-20 15:07:00', 5, 'ACTIVE', 0, '2010-10-20 15:12:00', 0),
(2, 1, 1, '10 pixeles', 'VENTA', 'TIEMPO', '2010-10-16', '20:48:00', 45.54, 'USD', 1.25, '2010-10-19 19:00:00', 10, 'ACTIVE', 0, '2010-10-19 19:10:00', 0),
(3, 1, 1, 'Fusce vitae sapien sed ipsum hendrerit dignissim. Lorem ipsum dolor at tellus. onec nonummy magna quis risus. Quisque eleifend. Phasellus tempor vehicula justo. Aliquam lacinia metus ut elit oacis lorem.', 'COMPRA', 'TIEMPO', '0000-00-00', '18:41:00', 3000.00, 'USD', 305.00, '2010-10-19 18:41:00', 20, 'ACTIVE', 0, '2010-10-19 19:01:00', 0),
(4, 1, 1, 'celular GSM 850/900/1300/1850', 'COMPRA', 'TIEMPO', '2010-10-16', '11:44:18', 30000.00, 'USD', 4.00, '2010-10-19 17:41:00', 15, 'ACTIVE', 0, '2010-10-19 17:56:00', 0);
